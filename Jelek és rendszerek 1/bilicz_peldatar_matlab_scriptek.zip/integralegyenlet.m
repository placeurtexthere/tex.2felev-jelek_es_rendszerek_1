% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 5.7. pelda: Integralegyenlet megoldasa a momentum-modszerrel.
%
% *************************************************************************

clear all
close all
clc

% parameterek
A = 3; % a tartomany meretei
B = 2;

Nx = 32; % a felosztasok
Ny = 24;
N = Nx*Ny; % a cellak szama

Dx = 2*A/Nx; % cellak meretei
Dy = 2*B/Ny;

U = 1;
k = 1;

% a cellak kozeppontjainak koordinatai
x = (-A+Dx/2) : Dx : (A-Dx/2);
y = (-B+Dy/2) : Dy : (B-Dy/2);

[X, Y] = meshgrid(x, y);

X = reshape(X, N, 1);
Y = reshape(Y, N, 1);

% az egyutthato-matrix osszeallitasa
P = zeros(N, N);
 
for n = 1:N
    for m = n:N
        
        if n==m
            P(n,n) = 2*k*(Dx*log((Dy+sqrt(Dx^2+Dy^2))/Dx) + Dy*log((Dx+sqrt(Dx^2+Dy^2))/Dy));
        else
            P(n,m) = k*Dx*Dy/sqrt((X(m)-X(n))^2+(Y(m)-Y(n))^2);
            P(m,n) = P(n,m);
        end
        
    end
end

% az egyenletrendszer megoldasa
c = P\(U*ones(N,1));

% az eredmeny abrazolasa
surf(x,y,reshape(c,Ny,Nx))
xlabel('x')
ylabel('y')
zlabel('\sigma(x,y)')


