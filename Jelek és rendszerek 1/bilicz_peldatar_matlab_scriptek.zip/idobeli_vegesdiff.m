% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 6.7. pelda: Parcialis differencialegyenlet-rendszer megoldasa az idoben
% es terben veges differencia modszerrel (FDTD)
%
% *************************************************************************

clear all
close all
clc

% Parameterek
l = 1e3; % a vizsgalt szakasz hossza: 0 < z < l
N = 500; % a felosztasban szereplo pontok szama

% Terbeli felosztas
dz = (2*l)/(2*N-1); % hosszegyseg
zu = linspace(0, (l-dz/2), N); % az u(z,t) fgv. terbeli mintaveteli pontjai
zi = linspace(dz/2, l, N); % az i(z,t) fgv. terbeli mintaveteli pontjai

% Az egyenletekben szereplo konstansok
C = 80;
L = 0.2;

R = 0;
G = 0;

% % % % % % % vagy:

% R = 1e-8;
% G = 1e-2;

% A gerjesztes idobeli "szelessege"
T = 500;

% Az idobeli diszkretizacio
dt   = 5;               % idolepes nagysaga
tmax = 11000;           % a szimulacio vege
J    = round(tmax/dt);  % az idolepesek szama

% Az u(z,t) es i(z,t) fuggvenyek kezdeti erteke
u = zeros(1, N);
i = zeros(1, N);

t = 0;
for j = 1:J % ido szerinti ciklus
    t = t + dt;
    
    % A z=0 helyen az u(0,t) fgv. adott:
    u(1) = (1-stepfun(t,T))*sin(2*pi*t/T);
    
    % Ciklus az u(z,t) szamitasara a jelen pillanatban a megelozo
    % ertekekbol
    for k = 2:N
        u(k) = u(k) + dt*( -G/C*u(k) -1/C*(i(k)-i(k-1))/dz );
    end
    
    % Ciklus az i(z,t) szamitasara a jelen pillanatban a megelozo
    % ertekekbol (a z=l helyen i(l,t)=0 a peremfeltetel)
    for k = 1:N-1
        i(k) = i(k) + dt*( -R/L*i(k) -1/L*(u(k+1)-u(k))/dz );
    end
    
    % A pillanatnyi u(z) helyfuggveny kirajzolasa
    plot(zu,u)
    title(['t = ' num2str(t)], 'fontsize', 12)
    xlabel('z', 'fontsize', 12)
    ylabel('u(z)', 'fontsize', 12)
    grid on
    axis([0 l -2.1 2.1])
    pause(0.001)
    
end