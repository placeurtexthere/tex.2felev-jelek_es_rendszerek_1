% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 5.6. pelda: Numerikus integralas a teglanymodszerrel es a
% Simpson-szaballyal.
%
% *************************************************************************

clear all
close all
clc

f = @(x) sin(x).^3; % az integralando fuggveny formulaja

n = 128; % intervallumok szama (csak paros lehet)!

xi = linspace(0, pi/2, n+1); % a [0, pi/2] intervallum felosztasa

dx = (pi/2) / n;

I0 = dx*sum(f(xi(1:n)));

disp(['Az integral kozelitese teglanymodszerrel = ', num2str(I0)])

w = 2*ones(1,n+1);
w(2:2:end) = 4;
w(1) = 1;
w(n+1) = 1;

I2 = (dx/3)*sum(f(xi).*w);

disp(['Az integral kozelitese Simpson-modszerrel = ', num2str(I2)])

% a fuggveny es mintainak abrazolasa
xx = linspace(0, pi/2, 300);
plot(xx, f(xx), xi, f(xi), 'r o')