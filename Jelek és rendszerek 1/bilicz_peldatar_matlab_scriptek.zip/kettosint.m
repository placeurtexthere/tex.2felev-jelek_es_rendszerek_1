% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 10.8. pelda: Kettosintegral kiszamitasa teglanymodszerrel.
%
% *************************************************************************

% Ket, egysiku, kor alakul vekony vezetohurok kolcsonos induktivitasanak 
% szamitasa: a korok sugara "a" es "b", a kozeppontok tavolsaga "d".

a = 5;      % egyik kor sugara
b = 3;      % masik kor sugara
d = 10;     % kozeppontok tavolsaga

if (d <= (a+b) && d >= abs(b-a)) % a bemeneti adatok ellenorzese
    error('A korok nem metszhetik egymast!');
end

N = 80;     % az alfa szog szerinti osztopontok szama
M = 64;     % a beta szog szerinti osztopontok szama

Dalfa = 2*pi/N;
Dbeta = 2*pi/M;

alfa = 0 : Dalfa : (N-1)*Dalfa;
beta = 0 : Dbeta : (M-1)*Dbeta;

[A, B] = meshgrid(alfa, beta);

I = a*b*Dalfa*Dbeta*sum(sum( cos(B-A)./sqrt( (a*cos(A)-d-b*cos(B)).^2 + (a*sin(A)-b*sin(B)).^2 ) ));

disp(['Az integral ereteke = ' num2str(I)]);

