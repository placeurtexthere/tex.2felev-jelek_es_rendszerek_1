% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 4.4. pelda: Numerikus optimalizalas a gradiens- es a Newton-modszerrel.
%
% *************************************************************************

clear all
close all
clc

% a maximalizalando fuggveny:
P = @(r) r./(3+r).^2;

% az elso es masodik derivalt:
p1 = @(r) (3-r)./(3+r).^3;
p2 = @(r) (2*r-12)./(3+r).^4;

% tolerancia a leallashoz (az iteracio leall, ha |r(i+1) - r(i)|<delta)
delta = 1e-4;

% Gradiens-modszer
r(1) = 5; % kezdopont
lambda = 12; % lepeshossz parametere
i = 1;
while abs( p1(r(i))*lambda ) >= delta
    
    r(i+1) = r(i) + p1(r(i))*lambda;
    i = i + 1;
    
end

% Newton-modszer
rr(1) = 5; % kezdopont
lambda = 0.95; % lepeshossz parametere (lambda < 1 kell)
j = 1;
while abs( p1(rr(j))/p2(rr(j))*lambda ) >= delta
    
    rr(j+1) = rr(j) - p1(rr(j))/p2(rr(j))*lambda;
    j = j + 1;
    
end

% abrazolas
figure
plot(1:i,r, 'b o')
grid on
xlabel('iteracio (i)', 'fontsize', 12)
ylabel('r(i)', 'fontsize', 12)
title('Gradiens-modszer iteracioi', 'fontsize', 12)

figure
plot(1:j,rr, 'r s')
grid on
xlabel('iteracio (i)', 'fontsize', 12)
ylabel('r(i)', 'fontsize', 12)
title('Newton-modszer iteracioi', 'fontsize', 12)