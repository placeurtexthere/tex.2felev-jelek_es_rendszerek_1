% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 3.3. pelda: Nemlinearis egyenlet megoldasa a Newton-Raphson-modszerrel.
%
% *************************************************************************

clear all
clc

% parameterek:
T   = 1e-5;
tau = 4e-5;

% a fuggveny es derivaltja, amely zerushelyet keressuk: f(w)=0
f       = @(w) tan(w*T) + w*tau;
f_deriv = @(w) T*tan(w*T)^2 + T + tau;

% tolerancia (kis szam, amely az elvart pontossagot tukrozi)
delta = 1e-4;

% a kezdeti tipp a zerushelyre
w = 1.45*pi/T;

% lepes szamlalo
n = 1;

% iteracio
while abs(f(w)/f_deriv(w)) > delta
    w = w - f(w)/f_deriv(w);
    n = n + 1;
end

disp(['A kozelito megoldas: w = ', num2str(w)])
disp(['Elvegzett iteraciok szama: N = ', num2str(n)])