% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 3.4. pelda: Nemlinearis egyenlet megoldasa az
% intervallumfelezo-modszerrel.
%
% *************************************************************************

clear all
clc

% parameterek
U0 = 2;
I0 = 2;
R  = 3;
Us = 5;

% feladat az f fuggveny zerushelyenek megkereseses: 0 = f(in)
f = @(in) R*in + U0*log(in/I0 + 1) - Us;

% kezdeti tipp: a zerushely eleme az (a,b) intervallumnak
a = 0;  
b = 2;

% a tipp ellenorzese:
if f(a)*f(b)>0
    error('A kezdeti tipp rossz, mert f(a) es f(b) elojele azonos.');
end

% tolerancia (kis szam, amely az elvart pontossagot tukrozi)
delta = 1e-4;

% iterativ intervallumfelezes, amig (b-a)>delta teljesul
while (b-a)>delta
    x = (b+a)/2; % intervallum fele
    if f(x)*f(a) < 0 % f(x) elojele f(a) elojeletol kulonbozik, azaz f(b)
                     % elojelevel azonos   
        b = x;
    else
        a = x;
    end
end

disp(['A kozelito megoldas: in = ' num2str((b+a)/2)]);