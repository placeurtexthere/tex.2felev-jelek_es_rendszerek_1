% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 6.4. pelda: Veges differenciak modszere.
%
% *************************************************************************

% A megoldando differencialegyenlet: f''(x) = -20*cos(3*pi*x), 0<=x<=1
% Peremfeltetelek: f(0) = 0; f(1) = 1;

clear all
close all
clc

% A pontos megoldas: 
f = @(x) 20/(9*pi^2) * (cos(3*pi*x) + (9*pi^2/20+2)*x - 1);

% Veges differenciak modszere
N = 6;                  % resztartomanyok szama
dx = 1/N;               % lepeskoz (racstavolsag)
x = linspace(0,1, N+1); % racs

% egyutthato-matrix
A           = zeros(N+1, N+1);  % kesobb feltoltjuk
A(1,1)      = 1;                % phi_1 és phi_N ismeretek
A(N+1, N+1) = 1;

% jobb oldali vektor
B = zeros(N+1, 1);
B(1)   = 0;  % phi_1 = 0
B(N+1) = 1;  % phi_N = 1

for i=2:N
    A(i,i-1) = 1/dx^2;
    A(i,i+1) = 1/dx^2;
    A(i,i)   = -2/dx^2;
    
    B(i) = -20*cos(3*x(i)*pi);
end

phi = A\B; % linearis egyenletrendszer megoldasa

% Abrazolas
xx = linspace(0,1,300); % suru racs a pontos megoldas abrazolasahoz

plot(x,phi, 'r o',  xx, f(xx), 'b-', 'linewidth', 2)
grid on
xlabel('x', 'fontsize', 12)
ylabel('f(x)', 'fontsize', 12)
legend('veges differenciak', 'pontos', 'location', 'southeast')
set(gca, 'fontsize', 12)