% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 8.6. pelda: Gyors Fourier-transzformacio (FFT)
%
% *************************************************************************

clear all
close all
clc

% a fuggveny parameterei
T    = 5;   
tau  = 1.2;

% a mintaveteli pontok definialasa
N    = 16;              % a pontok szama
Tmax = 12;              % a vizsgalt idointervallum felso hatara
Dt   = Tmax/N;          % idolepes
t    = ( 0:(N-1) )*Dt;  % mintaveteli pontok

% a frekvenciapontok definialasa (az FFT algoritmus kovetkezmeny)
w    = (0 : (N-1))* 2*pi/Tmax;

% az idofuggveny
f = @(t) stepfun(t,0).*(1-exp(-t/tau)) + stepfun(t,T).*(exp(-(t-T)/tau)-1);

% a pontos spektrum
F_pontos = @(w) 2*sin(w*T/2).*(1./w - 1i*tau./(1+1i*w*tau)) .* exp(-1i*w*T/2);

% az FFT algoritmussal szamitott spektrum
F_fft = Dt*fft(f(t));

% abrazolas
tt = linspace(0, Tmax, 500); % suru idolepes az abrazolashoz
ww = linspace(0, 2*pi/Dt, 500); % suru frekvencialepes az abrazolashoz

ww(1) = 1e-8; % a pontos spektrum az ww=0 helyen nem ertelmezett, azonban 
              % hatarertke van, ezt kozelitjuk a 10^(-8) helyen felvett
              % ertekkel

figure
plot(tt,f(tt),'b', t, f(t), 'r o', 'LineWidth', 1.5)
xlabel('t','fontsize',12);
ylabel('f(t)','fontsize',12);
legend('idofuggveny','mintavett ertekek')
set(gca,'fontsize',12);

figure
plot(ww, real(F_pontos(ww)),'b', w, real(F_fft), 'r o', 'LineWidth', 1.5)
xlabel('\omega','fontsize',12);
ylabel('real F(j\omega)','fontsize',12);
legend('spektrum','FFT-vel kapott ertekek')
set(gca,'fontsize',12);
axis([-1e-3 inf -inf inf])

figure
plot(ww, imag(F_pontos(ww)),'b', w, imag(F_fft), 'r o', 'LineWidth', 1.5)
xlabel('\omega','fontsize',12);
ylabel('imag F(j\omega)','fontsize',12);
legend('spektrum','FFT-vel kapott ertekek')
set(gca,'fontsize',12);
axis([-1e-3 inf -inf inf])