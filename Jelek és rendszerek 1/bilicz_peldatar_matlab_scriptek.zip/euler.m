% *************************************************************************
% Melleklet az alabbi jegyzethez:
% Bilicz Sandor: A matematika villamosmernoki alkalmazasairol, peldakon 
% keresztul, 2013.
%
% 6.5. pelda: Differencialegyenlet megoldasa az elore- es a hatralepo 
% Euler-algoritmussal.
%
% *************************************************************************

clear all
close all
clc

T = 2;      % a vizsgalt idointervallum vege, (0 <= t <= T)
h = 0.1;    % idolepes (t=0, h, 2*h, 3*h, ...)
t = 0:h:T;

% a feladat parameterei
U0 = 1;
I0 = 1;
L = 0.4;
R = 1;

% a derivaltat megado fuggveny definicioja
f = @(i) (1+(i/I0)^2)*(-R/L*i+U0/L);

% lepesszam
n = length(t);

% helyfoglalas a megoldast tartalmazo vektoroknak
ie = zeros(1,n);    % elorelepo
ih = zeros(1,n);    % hatralepo

% elorelepo Euler-modszer
for k=1:(n-1)
    
    ie(k+1) = ie(k) + h*f(ie(k));
    
end

% hatralepo Euler-modszer
for k=1:(n-1)
    
    ih(k+1) = ih(k) + h*f(ih(k));
    
    for iteracio=1:5 % rogzitett szamu (5) iteracio ih(k+1) kozelitesere
        ih(k+1) = ih(k) + h*f(ih(k+1));
    end
end

% abrazolas
plot(t,ie, 'b-o', t, ih, 'r-o')
grid on
xlabel('t')
ylabel('i(t)')
legend('elorelepo', 'hatralepo','Location','southeast')
axis([0 T 0 max(ie)*1.1]);